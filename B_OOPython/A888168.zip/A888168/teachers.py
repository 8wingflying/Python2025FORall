def getTeachers():
    print("There are total 50 teachers")