def getStudents():
    print("There are total 2500 students")