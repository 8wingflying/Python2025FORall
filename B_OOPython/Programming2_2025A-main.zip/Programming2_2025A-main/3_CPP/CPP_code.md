# 程式碼
- Y. Daniel Liang C++程式設計導論 (第三版)
- CHAPTER 1 簡介電腦、程式，以及 C++
- CHAPTER 2 基本程式設計
- CHAPTER 3 選擇
- CHAPTER 4 數學函式、字元與字串
- CHAPTER 5 迴圈
- CHAPTER 6 函式
- CHAPTER 7 一維陣列
- CHAPTER 8 多維陣列
- CHAPTER 9 物件與類別
- CHAPTER 10 物件導向思維
- CHAPTER 11 指標與動態記憶體管理
- CHAPTER 12 樣版、向量與堆疊
- CHAPTER 13 檔案的輸入與輸出
- CHAPTER 14 運算子的多載
- CHAPTER 15 繼承與多型
- CHAPTER 16 異常處理
- CHAPTER 17 遞迴

CHAPTER 2 基本程式設計
## code1.cpp
```c
#include <iostream>

int main() {
std::cout << "Hello, World!";
// std::cout ==> 輸出到螢幕上
return 0;
}
```
## code2.cpp
- name constant ==>PI
```c
//2.4 ComputeAreaWithConstant.cpp

#include <iostream>
using namespace std;

int main()
{
  const double PI = 3.14159;

  // Step 1: Read in radius
  double radius;
  cout << "Enter a radius: ";
  cin >> radius;
  //cin ==> 從控制台讀取輸入資訊

  // Step 2: Compute area
  double area = radius * radius * PI;

  // Step 3: Display the area
  cout << "The area is ";
  cout << area << endl;

  return 0;
}
```
## code3.cpp
```c
// 2.5 LimitsDemo.cpp 
#include <iostream>
#include <limits>
using namespace std;

int main()
{
  cout << "INT_MIN is " << INT_MIN << endl;
  cout << "INT_MAX is " << INT_MAX << endl;
  cout << "LONG_MIN is " << LONG_MIN << endl;
  cout << "LONG_MAX is " << LONG_MAX << endl;
  cout << "FLT_MIN is " << FLT_MIN << endl;
  cout << "FLT_MAX is " << FLT_MAX << endl;
  cout << "DBL_MIN is " << DBL_MIN << endl;
  cout << "DBL_MAX is " << DBL_MAX << endl;

  return 0;
}
```


## code3.cpp
```c
// 四則運算
//2.7 DisplayTime.cpp
#include <iostream>
using namespace std;

int main()
{
  // Prompt the user for input
  int seconds;
  cout << "Enter an integer for seconds: ";
  cin >> seconds;
  int minutes = seconds / 60;
  int remainingSeconds = seconds % 60;
  cout << seconds << " seconds is " << minutes <<
    " minutes and " << remainingSeconds << " seconds " << endl;

  return 0;
}
```
## code4.cpp
```c
#include <iostream>
using namespace std;

int main()
{
  // Enter purchase amount
  double purchaseAmount;
  cout << "Enter purchase amount: ";
  cin >> purchaseAmount;

  double tax = purchaseAmount * 0.06;
  cout << "Sales tax is " << static_cast<int>(tax * 100) / 100.0;

  return 0;
}
```

# CHAPTER 3 選擇
## code5.cpp
```c
#include <iostream>
using namespace std;

int main()
{
  // Prompt the user to enter an integer
  int number;
  cout << "Enter an integer: ";
  cin >> number;

  if (number % 5 == 0)
    cout << "HiFive" << endl;

  if (number % 2 == 0 )
    cout << "HiEven" << endl;

  return 0;
}
```
## code6.cpp
```c
#include <iostream>
using namespace std;

int main()
{
  cout << "Enter a year: ";
  int year;
  cin >> year;

  // Check if the year is a leap year
  bool isLeapYear =
    (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);

  // Display the result in a message dialog box
  if (isLeapYear)
    cout << year << " is a leap year" << endl;
  else
    cout << year << " is a not leap year" << endl;

  return 0;
}
```
## code7.cpp
```

```

## code8.cpp
```

```
## code9.cpp
```

```
## code10.cpp
```
#include <iostream>
using namespace std;

int binarySearch(const int list[], int key, int listSize);

int main()
{
  int list[] = {1, 4, 4, 2, 5, -3, 6, 2};
  int i = binarySearch(list, 4, 8);  // returns 1
  int j = binarySearch(list, -4, 8); // returns -1
  int k = binarySearch(list, -3, 8); // returns 5

  cout << i << " " << j << " " << k << endl;
  return 0;
}

int binarySearch(const int list[], int key, int listSize)
{
  int low = 0;
  int high = listSize - 1;

  while (high >= low)
  {
    int mid = (low + high) / 2;
    if (key < list[mid])
      high = mid - 1;
    else if (key == list[mid])
      return mid;
    else
      low = mid + 1;
  }

  return -low - 1;
}
```
## code11.cpp
```

```

## code12.cpp
```

```


## code13.cpp
```

```
## code14.cpp
```

```
## code15.cpp
```

```
## code16.cpp
```

```
## code17.cpp
```

```

## code18.cpp
```

```
## code19.cpp
```

```
# 物件導向程式設計
## code20.cpp
```
class MyClass {       // The class
  public:             // Access specifier
    int myNum;        // Attribute (int variable)
    string myString;  // Attribute (string variable)
};

int main() {
  MyClass myObj;  // Create an object of MyClass

  // Access attributes and set values
  myObj.myNum = 15; 
  myObj.myString = "Some text";

  // Print attribute values
  cout << myObj.myNum << "\n";
  cout << myObj.myString;
  return 0;
}
```
- https://www.w3schools.com/cpp/cpp_classes.asp

## code21.cpp
```
// Create a Car class with some attributes
class Car {
  public:
    string brand;   
    string model;
    int year;
};

int main() {
  // Create an object of Car
  Car carObj1;
  carObj1.brand = "BMW";
  carObj1.model = "X5";
  carObj1.year = 1999;

  // Create another object of Car
  Car carObj2;
  carObj2.brand = "Ford";
  carObj2.model = "Mustang";
  carObj2.year = 1969;

  // Print attribute values
  cout << carObj1.brand << " " << carObj1.model << " " << carObj1.year << "\n";
  cout << carObj2.brand << " " << carObj2.model << " " << carObj2.year << "\n";
  return 0;
}
```

## code22.cpp
```

```


## code23.cpp
```

```
## code24.cpp
```

```
## code25.cpp
```

```
## code26.cpp
```

```
## code27.cpp
```

```

## code28.cpp
```

```
## code29.cpp
```

```
## code30.cpp
```

```

## code31.cpp
```

```

## code32.cpp
```

```


## code33.cpp
```

```
## code34.cpp
```

```
## code35.cpp
```

```
## code36.cpp
```

```
## code37.cpp
```

```

## code38.cpp
```

```
## code39.cpp
```

```
## code40.cpp
```

```
## code41.cpp
```

```

## code42.cpp
```

```


## code43.cpp
```

```
## code44.cpp
```

```
## code45.cpp
```

```
## code46.cpp
```

```
## code47.cpp
```

```

## code48.cpp
```

```
## code49.cpp
```

```
## code50.cpp
```

```

