## 開發環境
- Windows 開發工具: Dev-C++
- Linux 開發工具: g++
- 線上開發工具
  - [Online C++ Compiler - Programiz](https://www.programiz.com/cpp-programming/online-compiler/)
## [上課內容](content.md)與[程式範例](CPP_code.md)
## 線上資源
- https://www.geeksforgeeks.org/c-plus-plus/?utm_source=geeksforgeeks&utm_medium=gfgcontent_shm&utm_campaign=shm
## 延伸閱讀
- 經典[Bjarne Stroustrup |  The C++ Programming Language, 4th Edition](https://www.oreilly.com/library/view/the-c-programming/9780133522884)
- [C++ Primer, Fifth Edition](https://www.oreilly.com/library/view/c-primer-fifth/9780133053043/)
- [Secure Coding in C and C++, Second Edition](https://www.oreilly.com/library/view/secure-coding-in/9780132981989/)
- [Advanced C and C++ Compiling](https://learning.oreilly.com/library/view/advanced-c-and/9781430266679/)
- [Learn C++ by Example](https://learning.oreilly.com/library/view/learn-c-by/9781633438330/)
  - https://github.com/doctorlove/BootstrapCpp/ 
- [由重構學習 C++ 程式設計 Learn C++ Programming by Refactoring|劉邦鋒|國立臺灣大學出版中心](https://www.tenlong.com.tw/products/9787115637642?list_name=srh)
  - https://sites.google.com/view/cplusplusrefactor 
- [C++20 for Programmers: An Objects-Natural Approach, 3rd Edition](https://learning.oreilly.com/library/view/c-20-for-programmers/9780136905776/)
  - [學習 C++20 (中文版)](https://www.tenlong.com.tw/products/9787302625438?list_name=srh) 
