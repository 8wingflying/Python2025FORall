## 評分標準
- 只要交簡報 ==> 不能抄襲 ==>抄襲者零分
- 可以使用ChatGPT幫忙 ==> 但是你要知道為什麼
- A+報告 85-90 ==> 老師沒教的 足以展現具有學習熱情 頁數>= 100+
- A報告 80-85 ==> 所有老師提供的GITHUB的範例程式測試 + 部分老師沒教的  頁數>= 80+
- B報告 70-80 ==> 所有內容 (含指標 | 陣列 | 字串處理)  頁數>= 65+
- C(及格)報告 60-70 ==> 主要內容 (含指標 | 陣列 | 字串處理) 頁數>= =50+

## 教學錄影:
- [課程內容](https://youtu.be/RtZsfDN_DaM)
- [程式解說1](https://youtu.be/ZEyecVAIoAU)
- [Ch2. 結構化程式設計與程式解說2](https://youtu.be/ZEyecVAIoAU)
- [Ch2-3:結構化程式設計の重複性結構 loop](https://youtu.be/Bo5UJUDnmJ8)
- [Ch3: `函數`的程式設計 ==>  沒有錄到聲音](https://youtu.be/aA9NheK5_G4)

## 開發環境
- Windows 開發工具: Dev-C++
- Linux 開發工具: gcc
- 線上開發工具
  - https://www.onlinegdb.com/online_c_compiler
## [課程內容](CONTENT.md)
## 考試與測驗 
- [C Multiple Choice Questions](https://www.geeksforgeeks.org/c-multiple-choice-questions/?utm_source=geeksforgeeks&utm_medium=gfgcontent_shm&utm_campaign=shm)
- [C Programming Interview Questions (2025)](https://www.geeksforgeeks.org/c-interview-questions/?utm_source=geeksforgeeks&utm_medium=gfgcontent_shm&utm_campaign=shm)
## 參考資料
- [C 語言教學手冊, 4/e](https://www.tenlong.com.tw/products/9789574424849?list_name=srh)
- C語言程序設計 : 現代方法, 2/e (修訂版) C Programming: A Modern Approach, 2/e
  - 英文版
  - [簡體中譯本](https://www.tenlong.com.tw/products/9787115565198)
- 柴田望洋
  - [明解 C語言, 3/e (入門篇)](https://www.ituring.com.cn/book/914) [課本內容](C1.md)
    - https://github.com/shihyu/learn_c/tree/master/%E6%98%8E%E8%A7%A3C%E8%AA%9E%E8%A8%80/%E5%85%A5%E9%96%80%E7%AF%87
  - [明解C語言 中級篇](https://www.tenlong.com.tw/products/9787115464064?list_name=srh)
  - [明解C語言：實踐篇|[日]柴田望洋](https://www.tenlong.com.tw/products/9787115624970?list_name=srh)
- 線上學習資源
  - https://www.runoob.com/cprogramming/c-tutorial.html
  - https://www.geeksforgeeks.org/c-programming-language/?ref=shm
  - https://en.wikipedia.org/wiki/C_(programming_language)
  - https://www.w3schools.com/c/index.php



