# 小小測驗
- [程式閱讀題](程式閱讀題.md)

### Chapter 1: C語言基本語法
- 1-1.基本語法:資料型態(Data Type):識別字及關鍵字/變數與常數/資料型態的轉換
- 1-2.運算子與運算式 [各種運算子](運算子.MD)
- 1-3.輸出入方法: printf() 與scanf()
  - printf() ==> 輸出到螢幕
  - scanf() ==> 從鍵盤輸入 
- 1-4.程式碼的錯誤與Debug

## code1.c
```c
#include <stdio.h>

int main(void) {
	float miles;

	printf("A88168 也可以改成中文Please enter miles:");
	scanf("%f", &miles);

	float kilometers = miles * 1.6;

	printf("%f Kilometers", kilometers);
}

```
```c
#include <stdio.h>

int main() {
    printf("Hello, A88168 C!\n");
    return 0;
}
```
## code2.c 
```c
#include <stdio.h>
int main() {
    int intType;
    float floatType;
    double doubleType;
    char charType;

    // sizeof evaluates the size of a variable
    printf("Size of int: %zu bytes\n", sizeof(intType));
    printf("Size of float: %zu bytes\n", sizeof(floatType));
    printf("Size of double: %zu bytes\n", sizeof(doubleType));
    printf("Size of char: %zu byte\n", sizeof(charType));
    
    return 0;
}

```
- https://blog.csdn.net/luyao3038/article/details/131979922
## code2B.c
```c
#include <stdio.h>

int main(void) {
    printf("ASCII 編碼與解碼 初初階\n");
    printf("顯示字元 %c\n", 'A');
    printf("顯示為十進位整數 %d\n", 'A');
    printf("顯示為八進位整數 %o\n", 'A');
    printf("顯示為十六進位整數 %X\n", 'A');
    printf("顯示為十六進位整數 %x\n", 'A');
    
    return 0;
}
```
## code3.c 格式化輸入與輸出 | 算術運算子（Arithmetic Operators）
```
#include <stdio.h>
#include <math.h> 

int main()
{
   float a = 1.0, b = 6.0, c=4.0;
   printf ("%.4f", sqrt(a+b*c));
   return 0;
}
```
- sqrt()函數是定義在<math.h> ==> 所以必須要#include <math.h>
- 更多數學運算範例請參看
  - https://blog.hubspot.com/website/math-functions-c
  - https://www.w3schools.com/c/c_math.php

## code4.c bitwise運算子（Logical Operators）
```c
#include <stdio.h>
int main(int argc, char **argv)
{
    int x=9;
    int y=5;
    int result=(x^y);
    int result2=(x&&y);
    int result3=(x&y);
    printf("this is the smallest number %d \n", result);
    return 0;
}
```
- https://www.geeksforgeeks.org/bitwise-operators-in-c-cpp/
```c
#include <stdio.h>
int main(int argc, char **argv)
{
    int x=9;
    int y=5;
    int result=y^((x^y)&-(x<y));
    printf("this is the smallest number %d \n", result);
    return 0;
}
```

## code5.c 遞增和遞減運算字（Increment and Decrement Operators）
```c
#include <stdio.h>
int main()
{
   int a = 11111;
   printf("%d", a);
   a++;
   // a = a +1;
   printf("%d", a);
   return 0;
}
```
```c
#include <stdio.h>
int main()
{
   int a = 11111, b = 22222;
   printf("A888168 = %d\n", (a++)+(++b));
   // 11111 +22223
   printf("b= %d\n", b);
   printf("a = %d\n", a);   
   return 0;
}
```
```c
#include <stdio.h>
int main()
{
   int a = 11111, b = 22222;
   printf("%d", (a++)+(a+(++b)));
   return 0;
}
```
# Chapter 2
- 結構化程式設計(Structured Programming)技術
### 2-1:結構化程式設計(Structured Programming)
- 流程控制與流程圖
- 循序性結構(Sequential)、 選擇性結構(Selection) 與 重複性結構(Iteration)
### 2-2:結構化程式設計の選擇性結構:
- if、if-else、巢狀if、條件運算子敘述( ? :) 多重選擇
- switch/case敘述
#### 選擇性敘述 ==> 各類型 if switch
#### code6.c  if
```
#include<stdio.h>
 
int main()
{
    int num;
 
    printf("請輸入一個正整數 : ");
    scanf("%d",&num);
 
    if (num%2==0)
      printf("你輸入的偶數");
}
```
#### code7.c  if ..else ..
```
#include<stdio.h>
 
int main()
{
    int num;
 
    printf("請輸入一個正整數 : ");
    scanf("%d",&num);
 
    if (num%2==0)
      printf("你輸入的偶數\n");
    else
      printf("你輸入的奇數\n");
}
```

#### code8.c  `? :` 運算子(三元運算子)
```c
#include<stdio.h>
 
int main()
{
    int num;
 
    printf("請輸入一個正整數 : ");
    scanf("%d",&num);
 
    (num%2==0)?printf("偶數"):printf("奇數");
}
```
#### code9.c  if-else流程控制
```
試寫一個C程式，能判定輸入年份是否為閏年(leap year) 。
閏年判定方式：是4的倍數，但不是100的倍數：或者是400的倍數
　　例如：1800閏年，2000是閏年，2001不是閏年
```
```c
#include <stdio.h>
int main()
{
   int year;
   printf("判斷是否為閏年的C程式:請輸入你要的......年份"); 
   scanf("%d",&year);	

   if(((year%4==0)&&(year%100!=0))||(year%400==0))
       printf("%d 年是閏年.",year);
   else
       printf("%d 年不是閏年r",year);    

   return 0;
 }
```
#### code10.c  switch流程控制
```
#include <stdio.h>

int main()
{
   int x = 3;
   switch (x+1) {
     case 3:
       printf ("3  ");
     case 4:
       printf ("4  ");
     case 5:
       printf ("5  ");
       break;
     case 6:
       printf ("6  ");
     default:
       printf ("x");
     }
   return 0;
}
```
#### 範例練習:分別使用底下三種技術完成`找出3個數目中最大值的數字`
- (1) 使用 if Statement
- (2) 使用 if...else Ladder
- (3) 使用 Nested if...else 

### 2-3:結構化程式設計の重複性結構:
- For loop(迴圈) while loop(迴圈) do while loop(迴圈)
- 無窮迴圈、巢狀迴圈、空迴圈
- 迴圈的跳離: break 、continue、return與goto

#### code11.c
```
迴圈設計
題目:在console端輸入n == > 輸出:1+2+3+….+n的結果
使用三種loop技術撰寫
```
```c
//FOR LOOP

#include <stdio.h>
int main() {
    int n, i, sum = 0;

    printf("Enter a positive integer: ");
    scanf("%d", &n);

    for (i = 1; i <= n; ++i) {
        sum += i;  // sum = sum +i
    }

    printf("Sum = %d", sum);
    return 0;
}
```

```c
//while loop

#include <stdio.h>
int main() {
    int n, i, sum = 0;

    printf("Enter a positive integer: ");
    scanf("%d", &n);

    i = 1;
    while (i <= n) {
       sum += i;
       ++i;
    }


    printf("Sum = %d", sum);
    return 0;
}
```
```c

//DO While LOOP

#include <stdio.h>
int main() {
    int n, i, sum = 0;

    printf("Enter a positive integer: ");
    scanf("%d", &n);

    i = 1;
    do{
      sum += i;
      ++i;
    } while (i <= n);

    printf("Sum = %d", sum);
    return 0;
}
```
- 補充作業:在console端輸入n == > 輸出:n!=1*2*3*….*n的結果
  - 使用三種loop技術撰寫
  - 3!=3*2*1 =6

#### code12.c  多重迴圈範例: 99乘法表
```
#include <stdio.h>
int main() {
    int i,j;   
    for(i=1;i<=9;i++) {
        for(j=1;j<=9;j++)
            printf("%d*%d=%2d\t", i, j, i*j);
        printf("\n");
    }
    return 0;
}
```

### Chapter 3: 函數的程式設計
- 3-1:函數的基本架構: 函數的宣告與撰寫、引數與參數、傳回值
- 3-2:函數的呼叫方式: call by address vs call by value
- 3-3:遞迴函數(Recursive function)
- 3-4:函數使用的變數等級: 區域(local)、全域(global)與靜態、外部(extern)、暫存器變數(Register)

## code13.c
```
//main()在後 其他函數在前

#include <stdio.h>
 
int ifactorial(int z)
{
	int mul = 1, i = 1;
	while(i <= z)
	{
		mul *= i;
    //mul = mul*i;
		i++;
	};
	return mul;
}

int  main()
{
    int i = 4;
    printf("%d 的階乘為%d\n", i, ifactorial(i));
    return 0;
}
```

```c
//main()在前 其他函數在後
//要先宣告 ==> int fun(int);

#include <stdio.h>
#include <stdlib.h>

int a=10, fun(int);
// a == Global variable

int main(void) {

  int b=6;
  printf("a=%d, b=%d, fun(a)=%d\n", a, b, fun(a));
  return 0;
}

int fun(int b) {
  a -=5; b /=2;
  return(a+b);
}
```
## code14.c 函數呼叫
- 函數呼叫:call by value(傳值呼叫) vs call by address(傳址呼叫)| 兩個數字互換的C程式
```c
#include <stdio.h>
/* 函數的宣告 */
void swap (int a, int b);

int main (void) {
  int i = 11, j = 22;
  printf ("互換前:i = %d, j = %d\n" , i, j);
  swap (i, j);
  printf ("互換後:i = %d, j = %d\n" , i, j);
  return 0;
}

void swap (int a, int b) {
  printf ("互換前:a = %d, b = %d\n" , a, b);
  int temp = a;
  a = b;
  b = temp;
  printf ("互換後:a = %d, b = %d\n" , a, b);
}
```
## code15.c  遞迴函數1
```
遞迴函數(Recursive Function)程式設計:
Recursive function遞迴函數
[1]一個問題的內涵是由本身所定義的話，稱之為遞迴。
[2]遞迴函數是由上而下分析方法的一種特殊的情況，因為子問題本身和原來問題擁有相同的特性，只是範圍改變，範圍逐漸縮小到一個終止條件。
[3]遞迴函數的特性：
   a.遞迴函數在每次呼叫時，都可以使問題範圍逐漸縮小。
   b.函數需要擁有一個終止條件，以便結束遞迴函數的執行，否則遞迴函數並不會結束，而是持續的呼叫自已。
```
```
常見的遞迴函數:
1.N! 計算 N!階層函數: 4!=4*3*2*1=24  ==> f(n) = n*f(n-1);
2.f(n)=1+2+3+....+n ==>  級數和:1加到n的值  ==> f(n) = n + f(n-1);
3.費式序列Fibonacci Serie
4.二項式係數(Binomial coeff)
5.m與n的最大公因數(GCD).
6.河內塔（Tower of Hanoi）
```
```
小測驗:用遞迴求算1*2+2*3+3*4+…+(n-1)*n之和
```
```
遞迴式:f(n) = n*(n-1)(n-2)......1 = n*f(n-1)
   f(3)=3*f(2)=3*[2*f(1)]=3*[2*{1}]
終止式:f(1)=1
```
```c
#include <stdio.h>
 
double factorial(unsigned int i)
{
   if(i <= 1)
      return 1;
   else   return i * factorial(i - 1);
}

int  main()
{
    int i = 15;
    printf("%d 的階乘為%f\n", i, factorial(i));
    return 0;
}
```
## code16.c  遞迴函數2:費式序列Fibonacci Serie
```
費式序列Fibonacci Series: 0 1 1 2 3 5 8 13 21 34
f(0)=0, f(1)=1, f(n)=f(n-1)+f(n-2)
底下是用迴圈方式計算費式序列Fibonacci Serie
作業:使用遞迴函數方式計算費式序列Fibonacci Serie
```
```c
#include<stdio.h>    
void printFibonacci(int n){    
  static int n1=0,n2=1,n3;    

  if(n>0){    
    n3 = n1 + n2;    
    n1 = n2;    
    n2 = n3;    
    printf("%d ",n3);    
    printFibonacci(n-1);    
    }    
 }    

int main(){    
   int n;
  
   printf("請輸入你要列印幾項費式序列(要整數): ");    
   scanf("%d",&n);    
   printf("費式序列Fibonacci Series: ");    
   printf("%d %d ",0,1);//註解1:先列印前兩個費式序列   
   printFibonacci(n-2);//註解2:在印出其他費式序列   
   return 0;  
 }    
```


## code17.c  變數類型與scope(管轄範圍)
```c
#include <stdio.h>
 
/* 全域(global)變數宣告 */
int g = 20;

void printg()
{
  printf ("value of g in printg= %d\n",  g);
}

void printg2()
{
  /* 區域(local)變數宣告 */
  int g = 99;
  printf ("value of g in printg2= %d\n",  g);
}

int main ()
{
  /* 區域變數宣告 */
  int g = 10;

  printg();
  printg2();
  printf ("value of g in main= %d\n",  g);
 
  return 0;
}
```



### Chapter 4: 指標(Pointer)
- 4-1.指標變數:宣告與使用
- 4-2.指標運算子: 取址運算子&與取值運算子*
- 4-3.指標的運算:
  - 指標加法運算:加上整數
  - 指標減法運算:減去整數
  - 兩個指標相減
  - 指標比較

#### code20.c
```c
#include <stdio.h>

int main() {

 int x= 38;
// int *p=&x;
 int *p;
 //p == 指標變數===>存放位址(address)
 //&x == x 位址 ===> p=&x ==>P存放x位址(address)
 p=&x;

 //列印x 位址==> 使用&x
 printf("%p \n" , &x);
 //列印x 位址上的值==>
 printf("%d \n" , x);
 printf("%d \n" , *&x);
 //到p 存的x位址上取值
 printf("%d \n" , *p);
 printf("%p \n" , p);
 printf("%p \n" , p+3);

 return 0;

}
```
- 3-2:函數的呼叫方式: `call by address` vs call by value
- call by value(傳值呼叫 把value(值)傳到函數)
```c
#include <stdio.h>
/* 函數的宣告 */
void swap (int a, int b);

int main (void) {
  int i = 11, j = 22;
  printf ("互換前:i = %d, j = %d\n" , i, j);
  swap (i, j);
  printf ("互換後:i = %d, j = %d\n" , i, j);
  return 0;
}

void swap (int a, int b) {
  printf ("互換前:a = %d, b = %d\n" , a, b);
  int temp = a;
  a = b;
  b = temp;
  printf ("互換後:a = %d, b = %d\n" , a, b);
}
```
- `call by address` (傳址呼叫 把address(位址)傳到函數)

```c
#include <stdio.h>
/* 函數的宣告 */
void swap (int *a, int *b);

int main (void) {
  int i = 11, j = 22;
  printf ("互換前:i = %d, j = %d\n" , i, j);
  swap (&i, &j);
  printf ("互換後:i = %d, j = %d\n" , i, j);
  return 0;
}

void swap (int *a, int *b) {
  printf ("互換前:a = %d, b = %d\n" , *a, *b);
  int temp = *a;
  *a = *b;
  *b = temp;
  printf ("互換後:a = %d, b = %d\n" , *a, *b);
}
```
#### 4-3.指標的運算:
- 指標加法運算:加上整數
- 指標減法運算:減去整數
- 兩個指標相減
- 指標比較
```c
#include <stdio.h>
 
int main ()
{
   int n[10]={1,2,3,4,5,6}; //n 是一個包含 6個整數的陣列 //
   int *p;
   int *q;
   
   p = n; //把n的位址存到 P ==> p 指向n //
   q = n+4; //把n[4]的位址存到 q ==> q 指向n[4] //
   
   printf("答案1 = %d\n", *p );  
   printf("答案2A = %d\n", *q );     
   printf("答案2B = %d\n", n[4] );     
 
   //指標加法運算:加上整數
   p++;
   printf("答案3 = %d\n", *p );
 
   //指標加法運算:加上整數
   p = p + 3;
   printf("答案4 = %d\n", *p );
   
   //指標減法運算:減去整數
   q -=2;
   printf("答案5 = %d\n", *q ); 
   
   //指標相減
   printf("答案6 = %ld\n", p-q ); 
   return 0;
}
```
####  4-4.進階主題
- `指標函式(Function Pointers)`與`函式指標陣列(Array of Function Pointer)`
- https://mycollegenotebook.medium.com/%E6%8C%87%E6%A8%99%E5%87%BD%E5%BC%8F%E8%88%87%E9%99%A3%E5%88%97%E6%8C%87%E6%A8%99%E5%87%BD%E5%BC%8F-function-pointers-array-of-function-pointer-fb750e679444

#### Chapter 5: 陣列(Array)
- 5-1.一維陣列的基本語法
  - 宣告、配置記憶體、元素的表示方法、與初值的設定
- 5-2.陣列存取技術:
  - 使用索引(index)存取陣列
  - 使用指標(pointer)存取陣列
- 5-3.多維陣列 ==> 99乘法表

## code18.c 陣列
```
陣列的存取方式:
1.使用索引(index) 存取陣列資料
2.使用指標(pointer)存取陣列資料
```
```c
#include <stdio.h>
 
int main ()
{
   int n[10]; /* n 是一個包含 10 個整數的陣列 */
   int i,j;
 
   /* 初始化陣列元素 */         
   for ( i = 0; i < 10; i++ )
   {
      n[ i ] = i + 100; /* 設置元素 i 為 i + 100 */
   }
   
   /* 輸出陣列中每個元素的值 */
   for (j = 0; j < 10; j++ )
   {
      printf("Element[%d] = %d\n", j, n[j] );
   }
 
   return 0;
}
```
## 陣列存取技術1:使用索引(index)存取陣列
## code22.c
```c
#include <stdio.h>

int main(void) {
    int a[10] = {3,2,3,4,5,4,7,1,3,2};
    int b[10] = {0,0,0,0,0,0,0,0,0,0};

    for (i = 0 ; i < 10 ; i=i+1)
        b[a[i]-1] = b[a[i]-1] + 1;
   
    printf ("%d" , b[2] ) ;
    return 0;
}
```
## 陣列存取技術2:使用指標(pointer)存取陣列
```c
#include <stdio.h>
int main()
{
  int A[5] = {1, 2, 3, 4, 5};
  int* p = A + 3;
  printf("%d \n", p[1]);
}
```
```c
#include <stdio.h>
#include <stdlib.h>
#define SIZE 10

void fun(int *, int);

int main(void) {
  int x[SIZE] = {1,2,3,4,5,6,7,8,9,10};
  fun(x, SIZE);
  printf("\n");
  return 0;
}

void fun(int *a, int size) {
  if (size > 0) {
   fun(a+3, size-3);
   printf("*(a+%d)=%d\n", SIZE-size, *a);
  }
}
```
## 二維陣列（Two dimensional Arrays）
- https://mycollegenotebook.medium.com/c%E8%AA%9E%E8%A8%80%E7%AD%86%E8%A8%98-%E4%BA%8C%E7%B6%AD%E9%99%A3%E5%88%97-two-dimensional-arrays-f93c0752cb91

##### 難題小測驗 ==> 說明底下程式執行結果
```
#include <stdio.h>
int main()
{
  int array[5] = {100, 215, 321, 254, 165}; 
  int *k = &array[1]; 

  *k-- += 5; 
  *(++k) += 9; 
  *(k++) += 7; 
  *k++ -= 15; 

  for(int i = 0; i < 5; i++) 
  printf("%d ", array[i]); 
  return 0;
}
```
```c
#include <stdio.h>
int main()
{
  int arr[]= {203, 151 , 164, 154, 194};
  int *p = arr;
  
  *p++ += 10;
  *(p++) += 11;
  *(++p) += 9;
  
  for (int i= 0; i < 5; i++)
     printf("%d ", arr[i]);
  return 0;
}             
```
# Chapter 6: 字串(String)==字元陣列
- 6-1.字串的基本語法
  - 字串(String)與字元(Character)
  - 字串變數:宣告與初值的設定(String Initialization)
- 6-2.字串的存取:
  - 使用索引(index)存取字串
  - 使用指標(pointer)存取字串
- 6-3.字串的各種運算與常用的字串函數:字串反轉、合併、分割、排序

### 6-1.字串的基本語法
- 在其它程式語言，如Java語言都擁有專屬的字串資料型態
- C語言並沒有字串資料型態
- 字串是一種字元型態的陣列 ==> 使用’\0’字串結束字元標示字串的結束。
- 陣列是連續記憶體的變數集合，也就是由字元資料型態所組成的陣列結構。
- 【宣告】宣告一個字元陣列來儲存字串 ==> char str[15];
- 【初值設定1】字串的初值相當於指定C語言字元陣列的初值。
   - 使用「"」雙引號的字串常數指定陣列初值
     - `char str[15] = "hello, great\n"; `
     - char str[] = "GeeksforGeeks";
     - 在字元陣列的結束加上字元'\0'當作結束字元
- 【初值設定2】
  - char str[15] = {'h','e','l','l','o',',','','g','r','e','a','t','\n','\0'}; 

## code19.c  字串(==字元陣列)與字串處理(不使用指標)
- 字串在Ｃ語言中，以陣列的形式表現，並且用 ‘ \0 ’ 作為結束符號。
- 字串宣告==>要用雙冒號。==> char str[15] = "hello, great\n";
```c
#include <stdio.h>
 
int main ()
{
   char site[7] = {'D', 'R', 'A', 'G', 'O', 'N', '\0'};
   char site2[7] = {'D', 'R', '\0', 'A', 'G', 'O', 'N'};

   printf("龍大大的陣列作業: %s\n", site );
   printf("龍大大的陣列作業2: %s\n", site2 );
   //C 語言沒有為字串提供內建資料型態(data type)，但它有一個存取說明符 %s“ 可用來直接列印和讀取字串。 

   return 0;
}
```
- 初值設定的方法
- 方法1: char str[] = "GeeksforGeeks";  分配一個沒有大小的 String Literal
- 方法2: char str[50] = "GeeksforGeeks";  分配具有預定義大小的 String Literal
- 方法3: char str[14] = { 'G','e','e','k','s','f','o','r','G','e','e','k','s','\0'};
  - 逐個字元分配字串==> 應該記住將結束字元設置為 『\0』，這是一個 null 字元。 
- 方法4: char str[] = { 'G','e','e','k','s','f','o','r','G','e','e','k','s','\0'};
  - 逐個字元分配而不分配大小 

## code20.c  使用scanf讀取鍵盤輸入的字串
```c
#include<stdio.h>
  
int main()
{   
    // declaring string
    char str[50];
      
    // reading string特別注意 str是位址 因此不是寫成 `&str`
    // scanf("% 修飾子 ", 位址)
    scanf("%s",str);
      
    // print string
    printf("%s",str);
  
    return 0;
}
```
- https://www.geeksforgeeks.org/strings-in-c/
- 輸入底下兩種字串看看結果為何? c語言輸入是以空白鍵(whitespace)當作結束語
```
輸入1==> GeeksforGeeks
輸入2==> Geeks for Geeks
```
## 如何讀取C語言中由空格分隔的字串？
- https://www.geeksforgeeks.org/strings-in-c/
- 多種方法來讀取 C 中由空格分隔的字串
  - 方法1:使用 fgets（） 函數讀取一行字串，使用 gets（） 從標準輸入 （stdin） 中讀取字元並將它們儲存為 C 字串，直到到達換行符或文件結束 （EOF）
  - 方法2:使用 scanset 的字串輸入
```c
// 讀取有空白鍵的輸入方法1: 使用 fgets()函數

#include <stdio.h>
#define MAX 50
int main()
{
    char str[MAX];

    // MAX Size if 50 defined
    fgets(str, MAX, stdin);

    printf("String is: \n");

    // Displaying Strings using Puts
    puts(str);

    return 0;
}
```

```c
// 讀取有空白鍵的輸入方法2: 使用 scanset 的字串輸入
//scanset是 C 語言中的一項功能，它允許您指定 scanf 系列函數要讀取的一組字元。
//它們由 %[] 表示，可以包含單個字元或字元範圍。
//scanset區分大小寫，可以通過將字元放在方括弧內來定義。
//如果 scanset 的第一個字元是 ^，則說明符將在該字元首次出現后停止讀取。
//https://www.geeksforgeeks.org/scansets-in-c/

#include <stdio.h>

// driver code
int main()
{

    char str[20];

    // using scanset in scanf
    scanf("%[^\n]s", str);

    // printing read string
    printf("%s", str);

    return 0;
}
```
## code23.c  字串(==字元陣列)與字串處理(使用`指標`)
```
// C program to print string using Pointers
#include <stdio.h>

int main()
{

    char str[20] = "GeeksforGeeks";

    // Pointer variable which stores
    // the starting address of
    // the character array str

    char* ptr = str;

    // While loop will run till 
    // the character value is not
    // equal to null character

    // 將while loop中的*ptr != '\0' 改成 *ptr != 'k'  請問底下答案為何?
    while (*ptr != '\0') {
        printf("%c", *ptr);
      
        // moving pointer to the next character.
        ptr++;
    }

    return 0;
}
```
#### 6.3實作C程式的各種字串處理
- 使用C 內建的各字串處理函數

#### C 中有大量操作字串的函數：需要 #include <string.h>
- 標準 C 庫 :String.h 
- str`cpy`(s1, s2)== > 複製字串 s2 到字串 s1。
- str`cat`(s1, s2)== > 連接字串 s2 到字串 s1 的末尾。
- str`len`(s1)== >  返回字串 s1 的長度。
- str`cmp`(s1, s2)== >
  - 如果 s1 和 s2 是相同的，則返回 0；
  - 如果 s1<s2 則返回小於 0；
  - 如果 s1>s2 則返回大於 0。
- str`lwr`() ==> 將字串轉換為小寫
- str`upr`() ==> 將字串轉換為大寫
- str`chr`(s1, ch) ==> 返回一個指標，指向字串 s1 中字元 ch 的第一次出現的位置。
- str`str`(s1, s2)==> 返回一個指標，指向字串 s1 中字串 s2 的第一次出現的位置。
```c
#include <stdio.h>
#include <string.h>
 
int main ()
{
   char str1[9] = "CTFer";
   int  len ;

   len = strlen(str1);
   printf("strlen(str1) :  %d\n", len );

   return 0;
}
```

```c
#include <stdio.h>
#include <string.h>
 
int main ()
{
   char str1[9] = "CTFer";
   char str2[9] = "hacker";
   char str3[9];
   char str4[9];
   int  len ;
 
   /* 複製 str1 的內容複製到 str3 */
   strcpy(str3, str1);
   printf("strcpy( str3, str1) :  %s\n", str3 );
 
   /* 連接 str1 和 str2後的結果 存到str1 */
   strcat( str1, str2);
   printf("strcat( str1, str2):   %s\n", str1 );
 
    /* 連接 str2 和 str1後的結果 存到str1   */
   strcat( str2, str1);
   printf("strcat( str2, str1):   %s\n", str2 );
   
   /* 連接後，str1 的總長度 */
   len = strlen(str1);
   printf("strlen(str1) :  %d\n", len );
 
   strcpy(str4, str1);
   printf("strcpy( str4, str1) :  %s\n", str3 );
   str4[3] = '\0';
   printf(str4);
   
   return 0;
}
```
```
https://www.onlinegdb.com/online_c_compiler 

執行結果
main.c:38:11: warning: format not a string literal and no format arguments [-Wformat-security]    
    printf(str4 );                                                                                
           ^~~~                                                                                   
strcpy( str3, str1) :  CTFer                                                                      
strcat( str1, str2):   CTFerhacker                                                                
strcat( str2, str1):   erCTFerhacker                                                              
strlen(str1) :  22                                                                                
strcpy( str4, str1) :  cker                                                                       
*** stack smashing detected ***: ./a.out terminated                                               
CTFAborted (core dumped)    
```

```c
//修正後的程式
#include <stdio.h>
#include <string.h>
 
int main ()
{
   char str1[9] = "CTFer";
   char str2[9] = "hacker";
   char str3[9];
   char str4[9];
   int  len ;
 
   /* 複製 str1 的內容複製到 str3 與str 4 */
   strcpy(str4, str1);
   strcpy(str3, str1);
   printf("strcpy( str3, str1) :  %s\n", str3 );
 
   /* 連接 str1 和 str2後的結果 存到str1 */
   strcat( str1, str2);
   printf("strcat( str1, str2):   %s\n", str1 );
 
    /* 連接 str2 和 str1後的結果 存到str1   */
   //strcat( str2, str1);
   //printf("strcat( str2, str1):   %s\n", str2 );
   
   /* 連接後，str1 的總長度 */
   len = strlen(str1);
   printf("strlen(str1) :  %d\n", len );
 
   printf("strcpy( str4, str1) :  %s\n", str4 );
   str4[3] = '\0';
   printf("處理過的字串變成(請說明why?) :  %s\n",str4);
   
   return 0;
}
```

### 進階主題
- String Matching(字串比對) ==> 演算法
  - https://en.wikipedia.org/wiki/String-searching_algorithm
  - https://mycollegenotebook.medium.com/string-matching-%E5%AD%97%E4%B8%B2%E6%AF%94%E5%B0%8D-5475c5b66743
  - Naive String-Matching Algorithm
  - The Rabin-Karp Algorithm
  - String Matching with Finite Automata 
- 字串互換
- 字串反轉


### Chapter 7: 使用者自訂的的資料型態(User-defined data type)
- 7-1.結構(Structure)
- 7-2.共同空間 (Union)
- 7-3.列舉型態 (Enumeration)
- 7-4.使用者自定型態（typedef）
- 7-5.鏈結串列(linked list)

## 7-1.結構(Structure)
- https://mycollegenotebook.medium.com/%E7%B5%90%E6%A7%8B%E7%9A%84%E6%87%89%E7%94%A8-working-with-structures-f74c037e53bc
## code33.c
```

```
## code34.c
```

```
## code35.c
```

```
## code36.c
```

```
## code37.c
```

```

## code38.c
```

```
## code39.c
```

```
## code40.c
```

```
## code41.c
```

```

## code42.c
```

```


## code43.c
```

```
## code44.c
```

```
## code45.c
```

```
## code46.c
```

```
## code47.c
```

```

## code48.c
```

```
## code49.c
```

```
## code50.c
```

```
